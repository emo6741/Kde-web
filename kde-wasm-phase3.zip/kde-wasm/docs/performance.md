# Performance

Not measured yet. To fill after the first successful build: startup time, wasm size (raw/gzip/brotli),
memory usage, FPS, CPU usage, application launch time.
