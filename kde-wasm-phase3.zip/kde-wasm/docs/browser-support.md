# Browser support

Priority: Chromium, Firefox, Edge, Safari; Android Chrome separately.

| Browser | Status |
|---------|--------|
| Chromium/Chrome | untested |
| Firefox | untested |
| Edge | untested |
| Safari | untested |
| Android Chrome | untested (touch, virtual keyboard, orientation, fullscreen to be checked) |

Qt's docs state that if the browser supports WebAssembly, Qt should run; actual results to be recorded here.
Threads need SharedArrayBuffer, which needs cross-origin isolation (COOP/COEP) — off in Phase 1.
