# KDE port status

Legend: not started / analysed / builds / runs. **Everything below is an unverified initial
assessment; nothing has been built yet.**

## Qt layers

| Layer | Status |
|-------|--------|
| Qt Widgets hello world (Phase 1) | code written, not built |
| Qt Widgets GUI app (Phase 2: tabs, menu, toolbar, slider, style switch, notes via MEMFS, JS bridge) | code written, not built |
| Qt Quick / QML (Phase 3: Controls, animation, C++ backend, JS bridge) | code written, not built |
| Kirigami (Phase 4) | not started |

## KDE Frameworks (initial expectation only)

| Framework | Native dependency (expected) | Browser compat (expected) | WASM status | Patch needed |
|-----------|-----------------------------|---------------------------|-------------|--------------|
| KCoreAddons | process/file helpers | likely good | not started | unknown |
| KConfig | files, optional DBus | likely good | not started | unknown |
| KWidgetsAddons | Qt Widgets only | likely good | not started | unknown |
| KGuiAddons | clipboard/platform bits | partial | not started | unknown |
| KConfigWidgets | KConfig, KGuiAddons | likely OK after deps | not started | unknown |
| KJobWidgets | KJob, Widgets | likely OK | not started | unknown |
| KNotifications | DBus | needs layer | not started | yes |
| KWindowSystem | X11/Wayland | needs stub backend | not started | yes |
| KIO | sockets, worker processes | hard | not started | yes |
| Kirigami | Qt Quick | most realistic Qt Quick target | not started | unknown |

## Plasma / KWin components

KWin, Plasma Shell, KRunner, panel, widgets, notifications, system tray, wallpaper, task manager,
virtual desktops, settings: **not analysed yet** (Phase 8). KWin compositor/Wayland/X11 parts are
expected to be class D.

## Upstream tracking (fill in per repository)

| Repository | Upstream URL | Branch | Commit | Patches | Build requirements |
|------------|--------------|--------|--------|---------|--------------------|
| (none cloned yet) | | | | | |
