# Limitations

## Why KDE Plasma cannot simply run in a browser

| Dependency | Why it blocks | Class |
|------------|---------------|-------|
| Linux kernel interfaces, udev, libinput | no device/kernel access in sandbox | D |
| Wayland compositor (KWin) | needs DRM/KMS, input devices, sockets | D |
| X11 server | needs sockets, shared memory, devices | D (experimental research later) |
| systemd | process/service management unavailable | D |
| DBus daemon | no sockets/processes; session bus must be emulated | B |
| NetworkManager | system service | D (use fetch/WebSocket) |
| PipeWire / PulseAudio / ALSA | no native audio access | C (Web Audio via Qt) |
| OpenGL / Vulkan | native drivers unavailable | C (WebGL 2 via Qt/Emscripten; WebGPU future) |
| POSIX processes / fork / exec | not available | D |
| raw TCP/UDP sockets | not allowed | C (fetch, WebSocket, WebRTC) |
| shared memory between processes | no processes | D |
| filesystem | virtual FS only | B/C (MEMFS, IDBFS, OPFS) |
| threads | need SharedArrayBuffer + COOP/COEP | B |

Classes: A = ports directly, B = small compatibility layer, C = reimplement with browser API,
D = cannot work as-is in the browser sandbox.

This table is a **preliminary analysis from general knowledge**, not yet validated by building KDE code.

## Qt Quick specifics (Phase 3, expectations to verify)

- Qt Quick renders through WebGL; a browser/GPU without WebGL will show nothing.
- Headless CI browsers use software GL (SwiftShader flags in `tests/e2e.mjs`); speed there says nothing about real devices.
- Static plugin linking of QML modules depends on Qt's import scanner finding `QtQuick.Controls`; failures show up at link/start time.
