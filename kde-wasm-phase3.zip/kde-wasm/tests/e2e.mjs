// Browser test (Playwright): app starts, Qt canvas exists, JS can call C++.
// Usage: npm i playwright && npx playwright install chromium && node tests/e2e.mjs [url]
import { chromium } from "playwright";
const url = process.argv[2] || "http://localhost:8080/";
const browser = await chromium.launch({ args: ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"] });
const page = await browser.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(String(e)));
await page.goto(url);
await page.waitForFunction(() => window.kdeWasm && window.kdeWasm.ready, null, { timeout: 120000 });
const hasCanvas = await page.evaluate(() => !!document.querySelector("#screen canvas"));
const sum = await page.evaluate(() => window.kdeWasm.instance._kde_add(2, 3));
const slider = await page.evaluate(async () => {
  window.kdeWasm.instance._kde_set_slider(77);
  return window.kdeWasm.lastSlider; // set by C++ via EM_ASM after the Qt slider changed
});
let ok = true;
const check = (name, cond) => { console.log((cond ? "PASS " : "FAIL ") + name); ok = ok && cond; };
check("Qt canvas created", hasCanvas);
check("JS calls C++ (kde_add(2,3)==5)", sum === 5);
check("JS moves Qt/QML slider, C++ reports back (77)", slider === 77);
check("no page errors", errors.length === 0);
await browser.close();
process.exit(ok ? 0 : 1);
