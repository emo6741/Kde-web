#!/usr/bin/env bash
# Static checks: WASM binary and HTML launcher exist and look valid.
set -euo pipefail
D="${1:-wasm/dist}"
fail=0
for f in index.html loader.js style.css kde_wasm.js kde_wasm.wasm qtloader.js version.json; do
  if [ -s "$D/$f" ]; then echo "PASS $f"; else echo "FAIL $f missing/empty"; fail=1; fi
done
magic="$(head -c 4 "$D/kde_wasm.wasm" | od -An -tx1 | tr -d ' \n')"
[ "$magic" = "0061736d" ] && echo "PASS wasm magic" || { echo "FAIL wasm magic ($magic)"; fail=1; }
exit $fail
