# Contributing

- Never edit upstream KDE/Qt sources in place; put changes in `patches/` (e.g. `kconfig-wasm.patch`).
- Do not fake KDE with HTML/CSS/JS. Browser-only layers must be documented in `docs/architecture.md`.
- Never claim a component works unless it was built and run; record real status in `docs/kde-port-status.md`.
- Do not try to bypass the browser sandbox.
- Run `tests/check-artifacts.sh` and `tests/e2e.mjs` before opening a PR.
