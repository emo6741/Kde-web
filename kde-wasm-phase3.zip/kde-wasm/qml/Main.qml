import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import KdeWasm

ApplicationWindow {
    id: win
    visible: true
    width: 800
    height: 600
    title: "KDE WebAssembly Prototype"

    Backend { id: backend }

    header: ToolBar {
        Label {
            anchors.centerIn: parent
            text: "KDE WebAssembly Prototype (Qt Quick / QML)"
            font.bold: true
            font.pixelSize: 18
        }
    }

    footer: TabBar {
        id: bar
        TabButton { text: "Controls"; height: 56 }
        TabButton { text: "Animation"; height: 56 }
        TabButton { text: "JS Bridge"; height: 56 }
    }

    StackLayout {
        anchors.fill: parent
        currentIndex: bar.currentIndex

        // ---- Tab 1: Qt Quick Controls ----
        Item {
            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 20
                spacing: 12

                TextField {
                    id: nameField
                    Layout.fillWidth: true
                    Layout.preferredHeight: 48
                    placeholderText: "Your name"
                }
                Button {
                    text: "Greet"
                    Layout.fillWidth: true
                    Layout.preferredHeight: 56
                    onClicked: greeting.text = "Hello, "
                        + (nameField.text.length > 0 ? nameField.text : "stranger")
                        + "! This text comes from QML running as WebAssembly."
                }
                Label { id: greeting; text: "..."; wrapMode: Text.Wrap; Layout.fillWidth: true }

                RowLayout {
                    Layout.fillWidth: true
                    Slider {
                        id: slider
                        Layout.fillWidth: true
                        Layout.preferredHeight: 48
                        from: 0; to: 100; stepSize: 1
                        value: backend.sliderValue            // binding: C++ -> QML
                        onMoved: backend.sliderValue = value  // QML -> C++ (and on to JS)
                    }
                    Label { text: Math.round(backend.sliderValue); Layout.preferredWidth: 40 }
                }
                ProgressBar { Layout.fillWidth: true; from: 0; to: 100; value: backend.sliderValue }
                Switch { id: fancy; text: "Show list" ; checked: true }

                ListView {
                    id: list
                    visible: fancy.checked
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    model: ListModel { id: items }
                    delegate: ItemDelegate { width: list.width; text: model.name }
                    ScrollBar.vertical: ScrollBar {}
                }
                Button {
                    text: "Add list item"
                    Layout.fillWidth: true
                    Layout.preferredHeight: 56
                    onClicked: {
                        items.append({ name: "Item " + (items.count + 1) })
                        list.positionViewAtEnd()
                    }
                }
            }
        }

        // ---- Tab 2: scene graph / animation (exercises the WebGL renderer) ----
        Item {
            Rectangle {
                id: box
                width: 140; height: 140; radius: 20
                color: "#3daee9"
                anchors.centerIn: parent
                RotationAnimation on rotation { from: 0; to: 360; duration: 3000; loops: Animation.Infinite }
                Label { anchors.centerIn: parent; text: "Qt Quick"; color: "white"; font.bold: true }
                MouseArea {
                    anchors.fill: parent
                    onClicked: box.color = Qt.hsla(Math.random(), 0.7, 0.55, 1)
                }
            }
            Label {
                anchors { bottom: parent.bottom; horizontalCenter: parent.horizontalCenter; margins: 16 }
                text: "Tap the square to change its colour"
            }
        }

        // ---- Tab 3: JS <-> C++ ----
        Item {
            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 20
                spacing: 12
                Button {
                    text: "Read browser info (C++ -> JS)"
                    Layout.fillWidth: true
                    Layout.preferredHeight: 56
                    onClicked: info.text = backend.browserInfo()
                }
                Label { id: info; text: "Not read yet."; wrapMode: Text.Wrap; Layout.fillWidth: true }
                Button {
                    text: "Run C++ function"
                    Layout.fillWidth: true
                    Layout.preferredHeight: 56
                    onClicked: cppOut.text = "C++ ran. Click #" + backend.clicks + ", kde_add(" + backend.clicks
                        + ", 41) = " + backend.runCpp()
                }
                Label { id: cppOut; text: "Button not pressed yet."; wrapMode: Text.Wrap; Layout.fillWidth: true }
                Label { text: "Qt " + backend.qtVersion; Layout.fillWidth: true }
                Item { Layout.fillHeight: true }
            }
        }
    }
}
