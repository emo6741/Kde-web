#pragma once

#include <QMainWindow>

class QCheckBox;
class QComboBox;
class QLabel;
class QLineEdit;
class QListWidget;
class QProgressBar;
class QSlider;
class QTextEdit;

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

    // Called from JavaScript through the exported C function kde_set_slider().
    void setSliderValue(int value);

private slots:
    void onGreet();
    void onSliderChanged(int value);
    void onStyleChanged(const QString &name);
    void onAddItem();
    void saveNote();
    void loadNote();
    void readBrowserInfo();
    void runCppFunction();
    void showAbout();

private:
    QWidget *buildWidgetsTab();
    QWidget *buildNotesTab();
    QWidget *buildBridgeTab();
    QString notePath() const;

    QLineEdit *m_name = nullptr;
    QLabel *m_greeting = nullptr;
    QCheckBox *m_check = nullptr;
    QSlider *m_slider = nullptr;
    QLabel *m_sliderLabel = nullptr;
    QProgressBar *m_progress = nullptr;
    QComboBox *m_styleBox = nullptr;
    QListWidget *m_list = nullptr;
    QTextEdit *m_note = nullptr;
    QLabel *m_browserInfo = nullptr;
    QLabel *m_cppResult = nullptr;
    int m_clicks = 0;
};
