#include "Backend.h"

#include "export.h"

#include <QtGlobal>

static Backend *g_backend = nullptr;

extern "C" {
// JavaScript -> C++: instance._kde_add(a, b)
KDE_EXPORT int kde_add(int a, int b)
{
    return a + b;
}

// JavaScript -> C++ -> QML: moves the QML slider (instance._kde_set_slider(v))
KDE_EXPORT void kde_set_slider(int value)
{
    if (g_backend)
        g_backend->setSliderValue(value);
}
}

Backend::Backend(QObject *parent)
    : QObject(parent)
{
    g_backend = this;
}

Backend::~Backend()
{
    if (g_backend == this)
        g_backend = nullptr;
}

Backend *Backend::instance()
{
    return g_backend;
}

QString Backend::qtVersion() const
{
    return QString::fromLatin1(qVersion());
}

void Backend::setSliderValue(int v)
{
    v = qBound(0, v, 100);
    if (v == m_slider)
        return;
    m_slider = v;
    emit sliderValueChanged(v);
#ifdef __EMSCRIPTEN__
    // C++ -> JS hook defined in web/loader.js
    EM_ASM({
        if (window.kdeWasmOnSlider) { window.kdeWasmOnSlider($0); }
    }, v);
#endif
}

int Backend::runCpp()
{
    ++m_clicks;
    emit clicksChanged(m_clicks);
    const int result = kde_add(m_clicks, 41);
#ifdef __EMSCRIPTEN__
    EM_ASM({
        if (window.kdeWasmOnButton) { window.kdeWasmOnButton($0, $1); }
    }, m_clicks, result);
#endif
    return result;
}

QString Backend::browserInfo() const
{
#ifdef __EMSCRIPTEN__
    const QString ua = QString::fromUtf8(emscripten_run_script_string("navigator.userAgent"));
    const QString size = QString::fromUtf8(
        emscripten_run_script_string("window.innerWidth + 'x' + window.innerHeight"));
    const QString touch = QString::fromUtf8(emscripten_run_script_string("String(navigator.maxTouchPoints)"));
    return QStringLiteral("User agent: %1\nWindow: %2\nTouch points: %3").arg(ua, size, touch);
#else
    return QStringLiteral("Native build: no browser here.");
#endif
}
