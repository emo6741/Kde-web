#pragma once

#include <QObject>
#include <QString>
#include <QtQml/qqmlregistration.h>

// C++ object exposed to QML. Holds state that both QML and JavaScript can change.
class Backend : public QObject
{
    Q_OBJECT
    QML_ELEMENT
    Q_PROPERTY(int sliderValue READ sliderValue WRITE setSliderValue NOTIFY sliderValueChanged)
    Q_PROPERTY(int clicks READ clicks NOTIFY clicksChanged)
    Q_PROPERTY(QString qtVersion READ qtVersion CONSTANT)

public:
    explicit Backend(QObject *parent = nullptr);
    ~Backend() override;

    int sliderValue() const { return m_slider; }
    void setSliderValue(int v);
    int clicks() const { return m_clicks; }
    QString qtVersion() const;

    // Runs the C++ function kde_add() and notifies JavaScript.
    Q_INVOKABLE int runCpp();
    // C++ -> JS: reads browser information via the Emscripten JS bridge.
    Q_INVOKABLE QString browserInfo() const;
    // Called from the exported C function (JS -> C++).
    static Backend *instance();

signals:
    void sliderValueChanged(int value);
    void clicksChanged(int clicks);

private:
    int m_slider = 30;
    int m_clicks = 0;
};
