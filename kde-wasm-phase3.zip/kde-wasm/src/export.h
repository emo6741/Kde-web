#pragma once
// Marks a C function as callable from JavaScript (instance._name) in the WASM build.
#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#define KDE_EXPORT EMSCRIPTEN_KEEPALIVE
#else
#define KDE_EXPORT
#endif
