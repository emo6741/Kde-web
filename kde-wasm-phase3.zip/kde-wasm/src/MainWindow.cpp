#include "MainWindow.h"

#include "export.h"

#include <QAction>
#include <QApplication>
#include <QCheckBox>
#include <QComboBox>
#include <QDir>
#include <QFile>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QMenu>
#include <QMenuBar>
#include <QMessageBox>
#include <QProgressBar>
#include <QPushButton>
#include <QSlider>
#include <QStandardPaths>
#include <QStatusBar>
#include <QStyle>
#include <QStyleFactory>
#include <QTabWidget>
#include <QTextEdit>
#include <QToolBar>
#include <QVBoxLayout>

extern "C" int kde_add(int a, int b);

static MainWindow *g_window = nullptr;

extern "C" {
// JavaScript -> C++ -> Qt widget: moves the Qt slider (instance._kde_set_slider(v)).
KDE_EXPORT void kde_set_slider(int value)
{
    if (g_window)
        g_window->setSliderValue(value);
}
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    g_window = this;
    setWindowTitle(QStringLiteral("KDE WebAssembly Prototype"));

    // --- menu bar ---
    QMenu *fileMenu = menuBar()->addMenu(tr("&File"));
    QAction *saveAct = fileMenu->addAction(tr("&Save note"));
    QAction *loadAct = fileMenu->addAction(tr("&Load note"));
    QMenu *helpMenu = menuBar()->addMenu(tr("&Help"));
    QAction *aboutAct = helpMenu->addAction(tr("&About"));
    connect(saveAct, &QAction::triggered, this, &MainWindow::saveNote);
    connect(loadAct, &QAction::triggered, this, &MainWindow::loadNote);
    connect(aboutAct, &QAction::triggered, this, &MainWindow::showAbout);

    // --- tool bar (large icons-less buttons are fine for touch) ---
    QToolBar *tb = addToolBar(tr("Main"));
    tb->setMovable(false);
    tb->addAction(saveAct);
    tb->addAction(loadAct);

    // --- tabs ---
    auto *tabs = new QTabWidget(this);
    tabs->addTab(buildWidgetsTab(), tr("Widgets"));
    tabs->addTab(buildNotesTab(), tr("Notes"));
    tabs->addTab(buildBridgeTab(), tr("JS Bridge"));
    setCentralWidget(tabs);

    statusBar()->showMessage(QStringLiteral("KDE WebAssembly Prototype - Qt %1").arg(QString::fromLatin1(qVersion())));
}

MainWindow::~MainWindow()
{
    if (g_window == this)
        g_window = nullptr;
}

QWidget *MainWindow::buildWidgetsTab()
{
    auto *page = new QWidget;
    auto *root = new QVBoxLayout(page);

    auto *title = new QLabel(QStringLiteral("KDE WebAssembly Prototype"));
    QFont f = title->font();
    f.setPointSize(f.pointSize() + 6);
    f.setBold(true);
    title->setFont(f);
    title->setAlignment(Qt::AlignCenter);
    root->addWidget(title);

    auto *form = new QFormLayout;
    m_name = new QLineEdit;
    m_name->setPlaceholderText(tr("Your name"));
    m_name->setMinimumHeight(44);
    auto *greetBtn = new QPushButton(tr("Greet"));
    greetBtn->setMinimumHeight(56);
    m_greeting = new QLabel(tr("..."));
    form->addRow(tr("Name:"), m_name);
    root->addLayout(form);
    root->addWidget(greetBtn);
    root->addWidget(m_greeting);
    connect(greetBtn, &QPushButton::clicked, this, &MainWindow::onGreet);
    connect(m_name, &QLineEdit::returnPressed, this, &MainWindow::onGreet);

    m_check = new QCheckBox(tr("Uppercase greeting"));
    root->addWidget(m_check);

    // slider <-> progress bar <-> JavaScript
    auto *sliderRow = new QHBoxLayout;
    m_slider = new QSlider(Qt::Horizontal);
    m_slider->setRange(0, 100);
    m_slider->setValue(30);
    m_slider->setMinimumHeight(44);
    m_sliderLabel = new QLabel(QStringLiteral("30"));
    sliderRow->addWidget(m_slider, 1);
    sliderRow->addWidget(m_sliderLabel);
    root->addLayout(sliderRow);
    m_progress = new QProgressBar;
    m_progress->setRange(0, 100);
    m_progress->setValue(30);
    root->addWidget(m_progress);
    connect(m_slider, &QSlider::valueChanged, this, &MainWindow::onSliderChanged);

    // runtime Qt style switching (real Qt style engine)
    m_styleBox = new QComboBox;
    m_styleBox->addItems(QStyleFactory::keys());
    m_styleBox->setMinimumHeight(44);
    root->addWidget(new QLabel(tr("Qt style:")));
    root->addWidget(m_styleBox);
    connect(m_styleBox, &QComboBox::currentTextChanged, this, &MainWindow::onStyleChanged);

    // list
    auto *addBtn = new QPushButton(tr("Add list item"));
    addBtn->setMinimumHeight(56);
    m_list = new QListWidget;
    root->addWidget(addBtn);
    root->addWidget(m_list, 1);
    connect(addBtn, &QPushButton::clicked, this, &MainWindow::onAddItem);

    return page;
}

QWidget *MainWindow::buildNotesTab()
{
    auto *page = new QWidget;
    auto *root = new QVBoxLayout(page);
    m_note = new QTextEdit;
    m_note->setPlaceholderText(tr("Write a note. Save/Load use the Emscripten in-memory filesystem (MEMFS): "
                                  "the note is lost when you reload the page."));
    auto *row = new QHBoxLayout;
    auto *save = new QPushButton(tr("Save"));
    auto *load = new QPushButton(tr("Load"));
    save->setMinimumHeight(56);
    load->setMinimumHeight(56);
    row->addWidget(save);
    row->addWidget(load);
    root->addWidget(m_note, 1);
    root->addLayout(row);
    connect(save, &QPushButton::clicked, this, &MainWindow::saveNote);
    connect(load, &QPushButton::clicked, this, &MainWindow::loadNote);
    return page;
}

QWidget *MainWindow::buildBridgeTab()
{
    auto *page = new QWidget;
    auto *root = new QVBoxLayout(page);

    auto *infoBtn = new QPushButton(tr("Read browser info (C++ -> JS)"));
    infoBtn->setMinimumHeight(56);
    m_browserInfo = new QLabel(tr("Not read yet."));
    m_browserInfo->setWordWrap(true);

    auto *cppBtn = new QPushButton(tr("Run C++ function"));
    cppBtn->setMinimumHeight(56);
    m_cppResult = new QLabel(tr("Button not pressed yet."));
    m_cppResult->setWordWrap(true);

    root->addWidget(infoBtn);
    root->addWidget(m_browserInfo);
    root->addWidget(cppBtn);
    root->addWidget(m_cppResult);
    root->addStretch();

    connect(infoBtn, &QPushButton::clicked, this, &MainWindow::readBrowserInfo);
    connect(cppBtn, &QPushButton::clicked, this, &MainWindow::runCppFunction);
    return page;
}

void MainWindow::onGreet()
{
    QString name = m_name->text().trimmed();
    if (name.isEmpty())
        name = tr("stranger");
    QString text = tr("Hello, %1! This text was produced by C++ running as WebAssembly.").arg(name);
    if (m_check->isChecked())
        text = text.toUpper();
    m_greeting->setText(text);
}

void MainWindow::setSliderValue(int value)
{
    m_slider->setValue(value);
}

void MainWindow::onSliderChanged(int value)
{
    m_progress->setValue(value);
    m_sliderLabel->setText(QString::number(value));
#ifdef __EMSCRIPTEN__
    EM_ASM({
        if (window.kdeWasmOnSlider) { window.kdeWasmOnSlider($0); }
    }, value);
#endif
}

void MainWindow::onStyleChanged(const QString &name)
{
    if (QStyle *s = QStyleFactory::create(name)) {
        QApplication::setStyle(s);
        statusBar()->showMessage(tr("Qt style: %1").arg(name), 3000);
    }
}

void MainWindow::onAddItem()
{
    m_list->addItem(tr("Item %1").arg(m_list->count() + 1));
    m_list->scrollToBottom();
}

QString MainWindow::notePath() const
{
    QString dir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    if (dir.isEmpty())
        dir = QDir::tempPath();
    QDir().mkpath(dir);
    return dir + QStringLiteral("/note.txt");
}

void MainWindow::saveNote()
{
    QFile f(notePath());
    if (!f.open(QIODevice::WriteOnly | QIODevice::Text)) {
        statusBar()->showMessage(tr("Save failed: %1").arg(f.errorString()), 5000);
        return;
    }
    f.write(m_note->toPlainText().toUtf8());
    statusBar()->showMessage(tr("Saved to %1 (in-memory)").arg(f.fileName()), 5000);
}

void MainWindow::loadNote()
{
    QFile f(notePath());
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
        statusBar()->showMessage(tr("Load failed: %1").arg(f.errorString()), 5000);
        return;
    }
    m_note->setPlainText(QString::fromUtf8(f.readAll()));
    statusBar()->showMessage(tr("Loaded %1").arg(f.fileName()), 5000);
}

void MainWindow::readBrowserInfo()
{
#ifdef __EMSCRIPTEN__
    const QString ua = QString::fromUtf8(emscripten_run_script_string("navigator.userAgent"));
    const QString size = QString::fromUtf8(
        emscripten_run_script_string("window.innerWidth + 'x' + window.innerHeight"));
    const QString touch = QString::fromUtf8(
        emscripten_run_script_string("String(navigator.maxTouchPoints)"));
    m_browserInfo->setText(tr("User agent: %1\nWindow: %2\nTouch points: %3").arg(ua, size, touch));
#else
    m_browserInfo->setText(tr("Native build: no browser here."));
#endif
}

void MainWindow::runCppFunction()
{
    ++m_clicks;
    const int result = kde_add(m_clicks, 41);
    m_cppResult->setText(tr("C++ slot ran. Click #%1, kde_add(%1, 41) = %2").arg(m_clicks).arg(result));
#ifdef __EMSCRIPTEN__
    EM_ASM({
        if (window.kdeWasmOnButton) { window.kdeWasmOnButton($0, $1); }
    }, m_clicks, result);
#endif
}

void MainWindow::showAbout()
{
    QMessageBox::about(this, tr("About"),
                       tr("KDE WebAssembly Prototype, Phase 2.\nReal Qt %1 widgets compiled to WebAssembly.\n"
                          "No KDE Frameworks are included yet.")
                           .arg(QString::fromLatin1(qVersion())));
}
