#include <QApplication>

#include "MainWindow.h"
#include "export.h"

// Plain C function callable from JavaScript as instance._kde_add(a, b).
extern "C" {
KDE_EXPORT int kde_add(int a, int b)
{
    return a + b;
}
}

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("kde-wasm"));

    MainWindow window;
    window.resize(800, 600);
    window.show();

    return app.exec();
}
