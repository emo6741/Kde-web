# kde-wasm

Goal: run as much **real** KDE/Qt C++ code as possible in a browser via
C++ -> CMake -> Emscripten -> WebAssembly. This is **not** an HTML/CSS imitation of KDE.
Where a Linux system component cannot run in the browser sandbox, a documented
browser compatibility layer may replace it (see `docs/`).

## Status

**Phases 1-3 (hello world, Qt Widgets, Qt Quick/QML): code written, NOT yet built or run by the author.**
Nothing here has been verified in a browser yet. The first real test is your first build / CI run.
KDE Frameworks, Kirigami and Plasma: not started (see `docs/kde-port-status.md`).

## Phase 3 contents (default UI)

Qt Quick / QML app (`qml/Main.qml`, `src/Backend.*`): Qt Quick Controls (TextField, Button, Slider, ProgressBar,
Switch, ListView, TabBar), a rotating rectangle that exercises the WebGL scene-graph renderer, and the same
JS<->C++ bridge. Build with `KDE_WASM_UI=quick` (default); `KDE_WASM_UI=widgets` rebuilds Phase 2.
Kirigami (Phase 4) is not included yet.

## Phase 2 contents

Tabs (Widgets / Notes / JS Bridge), menu bar, toolbar, line edit, checkbox, slider + progress bar,
runtime Qt style switching, list widget, note save/load on the in-memory filesystem,
C++ -> JS (browser info, hooks) and JS -> C++ (`kde_add`, `kde_set_slider` moves a real Qt slider).

## Architecture

```
Qt C++ (src/) -> CMake -> Emscripten -> kde_wasm.wasm + kde_wasm.js + qtloader.js
                                             |
                       web/index.html + web/loader.js (progress, errors, JS<->C++ test)
```

## Requirements

- Emscripten SDK (the version Qt documents for your Qt release, see BUILDING.md)
- Qt for WebAssembly kit + matching Qt desktop kit
- CMake >= 3.21, Python 3, optionally Ninja
- A Linux x86_64 machine or GitHub Actions. **Android tablets cannot build this** (see BUILDING.md).

## Quick start

```bash
git clone <your-repo-url> kde-wasm && cd kde-wasm
source <emsdk>/emsdk_env.sh
export QT_WASM_PREFIX=$HOME/Qt/<version>/wasm_singlethread
./scripts/build-wasm.sh
./scripts/serve.sh          # then open http://localhost:8080
```

Native Linux build of the same code: `cmake -B build && cmake --build build`.

## Getting a URL for the tablet

Push to `main`; the workflow publishes `wasm/dist` to GitHub Pages (enable once under
Settings -> Pages -> Source: GitHub Actions). Open that URL in Android Chrome.
The HTML files alone (`web/`) cannot run without the compiled `kde_wasm.wasm`.

## Local server and threading

Never open the app through `file://`. `scripts/serve.sh` serves `wasm/dist` with correct
WASM MIME type and no-cache headers. Phase 1 is single-threaded, so
SharedArrayBuffer and cross-origin isolation are **not required**. For a future threaded
build: `./scripts/serve.sh 8080 --isolate` adds `Cross-Origin-Opener-Policy: same-origin`
and `Cross-Origin-Embedder-Policy: require-corp`.

## Browser compatibility

Target order: Chromium, Firefox, Edge, Safari; Android Chrome tested separately. Not yet tested.
See `docs/browser-support.md`.

## Known limitations

See `docs/limitations.md`.

## KDE port status

See `docs/kde-port-status.md`.

## Troubleshooting

- Blank page / "Could not load kde_wasm.js": run `./scripts/build-wasm.sh` first, serve via http.
- Link or compile errors right after upgrading Qt: Emscripten version mismatch.
- Loader error "qtLoad is not a function": the Qt loader API changed; compare `web/loader.js` with the
  `kde_wasm.html` that Qt generates in `build-wasm/`.
- JS->C++ button says `_kde_add is not exported`: check `extern "C"` + `EMSCRIPTEN_KEEPALIVE` in `src/main.cpp`.
