// Browser loader for the Qt/WASM app. Qt's own qtloader.js does the real work;
// this file only shows progress, loads scripts and reports errors.
(function () {
  "use strict";
  const APP = "kde_wasm";
  const $ = (id) => document.getElementById(id);
  const stages = [
    "Loading KDE WebAssembly...",
    "Initializing Qt...",
    "Loading WASM...",
    "Starting application...",
    "Application Ready",
  ];
  let stageIdx = 0;
  function stage(i) {
    stageIdx = i;
    $("stage").textContent = stages[i];
    $("bar").value = i;
  }
  function fail(msg) {
    $("stage").textContent = "Failed to start (stage: " + stages[stageIdx] + ")";
    const e = $("error");
    e.hidden = false;
    e.textContent = msg + "\n\nHints:\n- Open via http://localhost (not file://). Use scripts/serve.sh.\n" +
      "- Check that kde_wasm.js, kde_wasm.wasm and qtloader.js exist next to index.html.\n" +
      "- Open the browser console for details.";
    console.error("[kde-wasm]", msg);
  }
  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = src;
      s.onload = resolve;
      s.onerror = () => reject(new Error("Could not load " + src));
      document.head.appendChild(s);
    });
  }

  window.kdeWasm = window.kdeWasm || {};
  // C++ -> JS hook: the Qt slider changed (also fires when JS moved it)
  window.kdeWasmOnSlider = function (value) {
    window.kdeWasm.lastSlider = value;
    const el = $("jsSlider");
    if (el && String(el.value) !== String(value)) el.value = value;
  };

  // C++ -> JS hook (called from MainWindow::runCppFunction via EM_ASM)
  window.kdeWasmOnButton = function (clicks, result) {
    $("jsOut").textContent = "C++ told JS: click #" + clicks + ", kde_add result = " + result;
  };

  async function main() {
    if (!window.WebAssembly) throw new Error("This browser has no WebAssembly support.");
    // Cache busting: version.json is written by scripts/build-wasm.sh and fetched uncached.
    let v = "dev";
    try {
      const r = await fetch("version.json", { cache: "no-store" });
      if (r.ok) v = (await r.json()).build || v;
    } catch (_) { /* optional */ }

    stage(1);
    await loadScript(APP + ".js?v=" + v);       // defines window.kde_wasm_entry
    await loadScript("qtloader.js?v=" + v);     // defines qtLoad()
    if (typeof qtLoad !== "function") throw new Error("qtloader.js did not define qtLoad().");

    stage(2);
    const instance = await qtLoad({
      qt: {
        entryFunction: window[APP + "_entry"],
        containerElements: [$("screen")],
        onExit: (exit) => fail("Application exited: " + JSON.stringify(exit)),
      },
    });

    stage(3);
    Object.assign(window.kdeWasm, { instance: instance, ready: true });
    $("jsCall").addEventListener("click", () => {
      try {
        if (typeof instance._kde_add !== "function") throw new Error("instance._kde_add is not exported");
        const r = instance._kde_add(2, 3);
        $("jsOut").textContent = "JS called C++: kde_add(2, 3) = " + r;
      } catch (e) { $("jsOut").textContent = "JS->C++ call failed: " + e.message; }
    });
    $("jsSlider").addEventListener("input", (ev) => {
      if (typeof instance._kde_set_slider === "function") instance._kde_set_slider(+ev.target.value);
    });
    $("jsbar").hidden = false;
    stage(4);
    setTimeout(() => { $("loading").hidden = true; }, 300);
  }

  main().catch((e) => fail(e && e.message ? e.message : String(e)));
})();
