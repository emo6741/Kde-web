#!/usr/bin/env bash
# Build the Qt/WebAssembly prototype.
#
# Required environment:
#   QT_WASM_PREFIX  Qt WebAssembly kit, e.g. $HOME/Qt/<qt-version>/wasm_singlethread
# Optional:
#   QT_HOST_PATH    Qt desktop kit of the SAME version (only needed for the plain emcmake path)
#   KDE_WASM_UI     quick (default, Phase 3) or widgets (Phase 2)
#   BUILD_DIR       default: build-wasm
#   DIST_DIR        default: wasm/dist
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="${BUILD_DIR:-$ROOT/build-wasm}"
DIST_DIR="${DIST_DIR:-$ROOT/wasm/dist}"

report() { # report <error> <status> <action>
  printf '\nERROR:\n%s\n\nSTATUS:\n%s\n\nSUGGESTED ACTION:\n%s\n\n' "$1" "$2" "$3" >&2
  exit 1
}

echo "==> 1/8 Environment check"
for t in cmake python3; do
  command -v "$t" >/dev/null || report "$t not found." "Required build tool is missing." "Install $t and re-run."
done
command -v ninja >/dev/null && GEN=(-G Ninja) || GEN=()

echo "==> 2/8 Emscripten check"
command -v em++ >/dev/null || report "em++ not found." "Emscripten SDK is not active in this shell." \
  "Install emsdk (see BUILDING.md), then: source <emsdk>/emsdk_env.sh"
echo "    $(em++ --version | head -n1)"
echo "    NOTE: Qt requires the Emscripten version documented for your Qt release (see BUILDING.md)."

echo "==> 3/8 Qt check"
[ -n "${QT_WASM_PREFIX:-}" ] || report "QT_WASM_PREFIX is not set." "No Qt WebAssembly kit configured." \
  "export QT_WASM_PREFIX=\$HOME/Qt/<version>/wasm_singlethread"
[ -d "$QT_WASM_PREFIX" ] || report "QT_WASM_PREFIX does not exist: $QT_WASM_PREFIX" "Qt kit not found." \
  "Install the 'WebAssembly (single-threaded)' component with the Qt installer or aqtinstall."

echo "==> 4/8 CMake configure"
if [ -x "$QT_WASM_PREFIX/bin/qt-cmake" ]; then
  "$QT_WASM_PREFIX/bin/qt-cmake" -S "$ROOT" -B "$BUILD_DIR" "${GEN[@]}" -DCMAKE_BUILD_TYPE="${CMAKE_BUILD_TYPE:-Release}" -DKDE_WASM_UI="${KDE_WASM_UI:-quick}" \
    || report "CMake configure failed." "See CMake output above." "Check that Emscripten and Qt versions match."
else
  [ -n "${QT_HOST_PATH:-}" ] || report "qt-cmake missing and QT_HOST_PATH not set." "Cannot configure via emcmake." \
    "Set QT_HOST_PATH to the Qt desktop kit of the same version."
  emcmake cmake -S "$ROOT" -B "$BUILD_DIR" "${GEN[@]}" -DCMAKE_BUILD_TYPE="${CMAKE_BUILD_TYPE:-Release}" -DKDE_WASM_UI="${KDE_WASM_UI:-quick}" \
    -DCMAKE_PREFIX_PATH="$QT_WASM_PREFIX" -DQT_HOST_PATH="$QT_HOST_PATH" \
    || report "CMake configure failed." "See CMake output above." "Check Qt/Emscripten versions."
fi

echo "==> 5/8 Dependency build (none yet: Phase 1 depends only on Qt)"
echo "==> 6/8 Component build"
cmake --build "$BUILD_DIR" -j "$(nproc 2>/dev/null || echo 2)" \
  || report "Compilation failed." "See compiler output above." "Fix the first error shown; it is usually a Qt/Emscripten version mismatch."

echo "==> 7/8 Collect WASM output"
for f in kde_wasm.js kde_wasm.wasm qtloader.js; do
  [ -f "$BUILD_DIR/$f" ] || report "Missing build output: $f" "Build finished but expected file is absent." \
    "Check that the target is named kde_wasm and the Qt WebAssembly platform was used."
done
rm -rf "$DIST_DIR"; mkdir -p "$DIST_DIR"
cp "$BUILD_DIR"/kde_wasm.js "$BUILD_DIR"/kde_wasm.wasm "$BUILD_DIR"/qtloader.js "$DIST_DIR"/
[ -f "$BUILD_DIR/qtlogo.svg" ] && cp "$BUILD_DIR/qtlogo.svg" "$DIST_DIR"/ || true

echo "==> 8/8 HTML launcher"
cp "$ROOT"/web/index.html "$ROOT"/web/loader.js "$ROOT"/web/style.css "$DIST_DIR"/
BUILD_ID="$(git -C "$ROOT" rev-parse --short HEAD 2>/dev/null || echo nogit)-$(date +%Y%m%d%H%M%S)"
printf '{"build":"%s"}\n' "$BUILD_ID" > "$DIST_DIR/version.json"
echo "Done: $DIST_DIR (build $BUILD_ID). Next: ./scripts/serve.sh"
