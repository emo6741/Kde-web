#!/usr/bin/env bash
# Usage: ./scripts/serve.sh [port] [--isolate]
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT="${1:-8080}"; shift || true
exec python3 "$DIR/serve.py" --port "$PORT" "$@"
