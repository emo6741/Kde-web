#!/usr/bin/env python3
"""Local dev server for the WASM build. Never open the app via file://."""
import argparse, functools, http.server, os

class Handler(http.server.SimpleHTTPRequestHandler):
    isolate = False
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map,
                      ".wasm": "application/wasm", ".js": "text/javascript"}

    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")
        if self.isolate:  # only needed for threaded builds (SharedArrayBuffer)
            self.send_header("Cross-Origin-Opener-Policy", "same-origin")
            self.send_header("Cross-Origin-Embedder-Policy", "require-corp")
        super().end_headers()

def main():
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    p = argparse.ArgumentParser()
    p.add_argument("--dir", default=os.path.join(root, "wasm", "dist"))
    p.add_argument("--port", type=int, default=8080)
    p.add_argument("--isolate", action="store_true", help="send COOP/COEP headers")
    a = p.parse_args()
    if not os.path.isfile(os.path.join(a.dir, "index.html")):
        raise SystemExit(f"No index.html in {a.dir}. Run ./scripts/build-wasm.sh first.")
    Handler.isolate = a.isolate
    h = functools.partial(Handler, directory=a.dir)
    print(f"Serving {a.dir} on http://localhost:{a.port} (isolation={'on' if a.isolate else 'off'})")
    http.server.ThreadingHTTPServer(("0.0.0.0", a.port), h).serve_forever()

if __name__ == "__main__":
    main()
