# Building

## Version pairing (from the official Qt docs)

Each Qt minor version targets one Emscripten version. Use the pair Qt documents:

| Qt | Emscripten |
|----|-----------|
| 6.11.x | 4.0.7 |
| 6.12.0 | 5.0.5 |

Source: https://doc.qt.io/qt-6/wasm.html . Re-check this page before upgrading;
`.github/workflows/wasm-build.yml` defaults to 6.11.1 / 4.0.7.

## Emscripten

```bash
git clone https://github.com/emscripten-core/emsdk.git
cd emsdk
./emsdk install <version-from-table>
./emsdk activate <version-from-table>
source ./emsdk_env.sh
em++ --version
```

## Qt

Install the Qt desktop kit and "WebAssembly (single-threaded)" of the same version
(Qt online installer or `aqtinstall`). Then:

```bash
export QT_WASM_PREFIX=$HOME/Qt/<version>/wasm_singlethread
export QT_HOST_PATH=$HOME/Qt/<version>/gcc_64   # only for the plain emcmake path
```

## Build

```bash
./scripts/build-wasm.sh
```
Manual equivalent: `$QT_WASM_PREFIX/bin/qt-cmake -B build-wasm && cmake --build build-wasm`.

## Android tablet workflow

The Qt WebAssembly kit and emsdk tools are x86_64 Linux/Windows/macOS binaries, so building
**on** the tablet is not realistic. Recommended:
1. Edit code on the tablet (AndroidIDE, Termux + git, or the GitHub web editor).
2. Push to GitHub; Actions builds and uploads the `kde-wasm-dist` artifact.
3. Download/serve the artifact and open it in Android Chrome (or publish it via GitHub Pages).
